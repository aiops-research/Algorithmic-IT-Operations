# Day Wise work

# 09 Jan 2021
1. Identified various log data sets - Apache, HDFS, Hadoop, SSH etc
2. Downloaded large size standard data sets 
3. Setup Environment to run Logparser on laptop
4. Pre-processed un-structured logs and transformed into structure format
5.
