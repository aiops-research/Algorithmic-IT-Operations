# High Level Actions

1. Pre-Process raw, unstructured data using Python
2. Prepare Train and Test data sets
3. Identify ML algorithm implementations for log analysis
4. Identify suitable algorithms for AIOPs use case 
